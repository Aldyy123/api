* List Error
- Update DU yang sudah lunas tidak bisa [x]
- Update SPP yang sudah lunas tidak bisa 
- Input RT dan RW masih BUG
- Kurang Study Year
- Contraint siswa resctrict must be change to cascade
- Family duplicate 
- Duplikasi Family
